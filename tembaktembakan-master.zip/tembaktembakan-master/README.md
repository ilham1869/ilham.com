 #print("Creative by")
    <br>"[1] Bintang Nur Pradana ")@bintang_nur_pradana
    <br>"[2] Masih dalam tahap pengembang ")
    Easy install
    1.Download termux di play store
    2.ketik "pkg install python;pkg install git;git clone https://github.com/Bintang73/tembaktembakan.git ;cd semut; python dor.py"(tanpa tanda petik") lalu enter
